from Currency import Currency

currency = Currency()

print(currency.convert(10)) # this converts this Dollar amount to Euro. Need to figure out how to input different currency values...
